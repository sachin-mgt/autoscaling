<?php
 \Magento\Framework\Component\ComponentRegistrar::register(\Magento\Framework\Component\ComponentRegistrar::MODULE, "\115\147\164\137\126\x61\x72\156\151\x73\x68", __DIR__);
