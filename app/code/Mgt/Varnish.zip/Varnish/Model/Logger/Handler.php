<?php
 namespace Mgt\Varnish\Model\Logger; class Handler extends \Magento\Framework\Logger\Handler\Base { const DEBUG = 100; protected $loggerType = 100; protected $fileName = "\57\x76\x61\162\57\154\x6f\x67\57\155\147\164\137\166\141\x72\156\151\163\150\x2e\x6c\x6f\147"; }
