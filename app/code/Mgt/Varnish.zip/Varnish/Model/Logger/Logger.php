<?php
 namespace Mgt\Varnish\Model\Logger; class Logger extends \Monolog\Logger { }
